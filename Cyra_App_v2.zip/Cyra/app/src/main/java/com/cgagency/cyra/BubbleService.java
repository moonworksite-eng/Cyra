package com.cgagency.cyra;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.*;
import android.widget.ImageView;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class BubbleService extends Service {
    private static final String TAG = "CyraBubble";
    private static final String CH = "cyra_bubble_ch";
    private static final int NID = 2001;
    private WindowManager wm;
    private View bubble;
    private WindowManager.LayoutParams lp;

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            createChannel();
            startForeground(NID, buildNotif());
            showBubble();
        } catch (Exception e) {
            Log.e(TAG, "onCreate error: " + e.getMessage());
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private void showBubble() {
        try {
            wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            if (wm == null) { stopSelf(); return; }

            ImageView iv = new ImageView(this);
            iv.setImageResource(R.drawable.bubble_circle);
            bubble = iv;

            float dp = getResources().getDisplayMetrics().density;
            int sz = (int)(58 * dp);

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            lp = new WindowManager.LayoutParams(sz, sz, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = 10;
            lp.y = 300;

            wm.addView(bubble, lp);

            bubble.setOnTouchListener(new View.OnTouchListener() {
                private int sx, sy;
                private float fx, fy;
                private boolean dragged;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = lp.x; sy = lp.y;
                            fx = e.getRawX(); fy = e.getRawY();
                            dragged = false;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            int dx = (int)(e.getRawX() - fx);
                            int dy = (int)(e.getRawY() - fy);
                            if (Math.abs(dx) > 6 || Math.abs(dy) > 6) dragged = true;
                            lp.x = sx + dx;
                            lp.y = sy + dy;
                            try { wm.updateViewLayout(bubble, lp); } catch (Exception ex) {}
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (!dragged) {
                                Intent i = new Intent(BubbleService.this, MainActivity.class);
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                                        | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                startActivity(i);
                            }
                            return true;
                    }
                    return false;
                }
            });

        } catch (Exception e) {
            Log.e(TAG, "showBubble error: " + e.getMessage());
            stopSelf();
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CH, "Cyra Bubble", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotif() {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CH)
                .setContentTitle("✦ Cyra")
                .setContentText("Tap to open")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setOngoing(true)
                .build();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onDestroy() {
        try {
            if (bubble != null && wm != null) {
                wm.removeView(bubble);
                bubble = null;
            }
        } catch (Exception e) {
            Log.e(TAG, "onDestroy: " + e.getMessage());
        }
        super.onDestroy();
    }
}
