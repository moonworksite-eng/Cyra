package com.cgagency.cyra;
import android.content.Intent;
import android.webkit.JavascriptInterface;

public class AndroidBridge {
    private final MainActivity activity;
    private final PrefManager pref;

    public AndroidBridge(MainActivity a) {
        activity = a;
        pref = new PrefManager(a);
    }

    @JavascriptInterface
    public String getCustomRules() { return pref.getCustomRules(); }

    @JavascriptInterface
    public void setCustomRules(String r) { pref.setCustomRules(r); }

    @JavascriptInterface
    public void startVoiceInput() { activity.runOnUiThread(activity::startVoice); }

    @JavascriptInterface
    public void speak(String text) { activity.runOnUiThread(() -> activity.speak(text)); }

    @JavascriptInterface
    public void toggleBubble() { activity.runOnUiThread(activity::toggleBubble); }

    @JavascriptInterface
    public void openSettings() {
        activity.runOnUiThread(() -> {
            Intent i = new Intent(activity, SettingsActivity.class);
            activity.startActivity(i);
        });
    }
}
