package com.cgagency.cyra;
import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    private static final String PREFS = "CyraPrefs";
    private final SharedPreferences prefs;

    public PrefManager(Context ctx) {
        prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public String getCustomRules() { return prefs.getString("rules", ""); }
    public void setCustomRules(String r) { prefs.edit().putString("rules", r).apply(); }
    public String getChatHistory() { return prefs.getString("history", "[]"); }
    public void setChatHistory(String h) { prefs.edit().putString("history", h).apply(); }
}
