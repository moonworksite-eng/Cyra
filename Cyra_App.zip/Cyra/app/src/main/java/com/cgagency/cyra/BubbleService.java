package com.cgagency.cyra;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.ImageView;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class BubbleService extends Service {
    private static final String CHANNEL_ID = "cyra_bubble";
    private static final int NOTIF_ID = 1001;
    private WindowManager wm;
    private View bubbleView;
    private WindowManager.LayoutParams params;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIF_ID, buildNotif());
        showBubble();
    }

    private void showBubble() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        bubbleView = new ImageView(this);
        ((ImageView) bubbleView).setImageResource(R.drawable.bubble_circle);
        int sz = (int)(60 * getResources().getDisplayMetrics().density);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(sz, sz, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0; params.y = 300;
        wm.addView(bubbleView, params);

        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int ix, iy; private float fx, fy; private boolean drag;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        ix = params.x; iy = params.y;
                        fx = e.getRawX(); fy = e.getRawY(); drag = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int)(e.getRawX()-fx), dy = (int)(e.getRawY()-fy);
                        if (Math.abs(dx)>8||Math.abs(dy)>8) drag=true;
                        params.x=ix+dx; params.y=iy+dy;
                        wm.updateViewLayout(bubbleView, params); return true;
                    case MotionEvent.ACTION_UP:
                        if (!drag) {
                            Intent i = new Intent(BubbleService.this, MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(i);
                        }
                        return true;
                }
                return false;
            }
        });
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Cyra Bubble",
                    NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotif() {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("✦ Cyra active hai")
                .setContentText("Bubble tap karke kahin se bhi baat karo")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi).setOngoing(true).build();
    }

    @Nullable @Override public IBinder onBind(Intent i) { return null; }
    @Override public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (bubbleView != null && wm != null) wm.removeView(bubbleView);
    }
}
